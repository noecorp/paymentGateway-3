import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { BeerListComponent } from './beer-list/beer-list.component';
import { BeerService } from './shared/beer/beer.service';

import { CRYPT_CONFIG_PROVIDER, CryptConfigProvider, EncryptionService } from 'angular-encryption-service';
import { EncryptionServiceModule } from 'angular-encryption-service';


const AppCryptConfigProvider: CryptConfigProvider = {
  getSalt(): Promise<string> {
    // TODO: implement providing a salt, which should be unique per user and
    // base64-encoded.
    return Promise.resolve('saltsalt');
  }
};

@NgModule({
  declarations: [
    AppComponent,
    BeerListComponent
  ],
  imports: [
    BrowserModule, HttpModule, EncryptionServiceModule.forRoot()
  ],
  providers: [BeerService, EncryptionService, {provide: CRYPT_CONFIG_PROVIDER, useValue: AppCryptConfigProvider}],
  bootstrap: [AppComponent]
})
export class AppModule { }
