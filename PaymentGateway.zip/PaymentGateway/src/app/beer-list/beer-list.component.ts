import { Component, OnInit } from '@angular/core';
import { BeerService } from '../shared/beer/beer.service';
import { EncryptionService } from '../services/encryption.service';
import * as shajs from 'sha.js';
import * as crypto from 'crypt';




@Component({
  selector: 'app-beer-list',
  templateUrl: './beer-list.component.html',
  styleUrls: ['./beer-list.component.css']
})
export class BeerListComponent implements OnInit {

  amount: number;
  bankAccountNumber: string;
  bankIfscCode: string;
  merchantTransactionRef: string;
  transactionDate: Date;
  paymentGatewayMerchantRefernce: string;
  msg: string;
  digest: string;
  payloadWithSHA: string;
  key: string;

  constructor(private beerService: BeerService, private encryptServive: EncryptionService) { }

  ngOnInit() {
    
   }


  public pay() {
    alert('I am getting called');
    this.merchantTransactionRef = 'txn001';
    this.amount=1000;
    this.bankAccountNumber='111111111111';
    this.bankIfscCode ='ICIC00000001';
    this.transactionDate= new Date();
    this.paymentGatewayMerchantRefernce  = 'merc001';
    this.key = 'Q9fbkB8au24wshGRW9ut8ecYpyXye5vhFLtHFdGjRg3a4HxPYRfQaKutZx5N4';

    this.msg  = 'bank_ifsc_code=' + this.bankIfscCode + '|bank_account_number=' + this.bankAccountNumber + '|amount=' + this.amount + 
    '|merchant_transaction_ref=' + this.merchantTransactionRef + '|transaction_date=' + this.transactionDate +
    '|payment_gateway_merchant_reference=' +  this.paymentGatewayMerchantRefernce;

     this.digest = shajs('sha256').update(this.msg).digest('hex');
     this.payloadWithSHA = this.msg +  '|hash=' + this.digest;

    let encryptedString = this.encryptServive.encrypt(this.payloadWithSHA,this.key)


  }

}
