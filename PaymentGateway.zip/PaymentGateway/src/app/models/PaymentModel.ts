export class PaymentModel {
    amount: number;
    bankAccountNumber: string;
    bankIfscCode: string;
    merchantTransactionRef: string;
    transactionDate: Date;
    paymentGatewayMerchantRefernce: string;
}
